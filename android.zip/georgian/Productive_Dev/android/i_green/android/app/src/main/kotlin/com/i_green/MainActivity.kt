package com.i_green

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
